# Code of Conduct

All participants are expected to uphold these values:

- Be respectful and inclusive.
- Assume good intentions.
- No harassment or discrimination.

For issues, contact the maintainer.